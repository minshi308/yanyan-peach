const DEFAULT = {
  lineLink: "https://line.me/R/ti/p/",
  phone1:"0978823328",
  phone2:"0981776979",
  products:[
    {name:"6粒禮盒", price:700, note:"數量有限需來電洽詢"},
    {name:"8粒禮盒", price:600, note:"大顆飽滿，送禮體面"},
    {name:"10粒禮盒", price:500, note:"份量剛好，實惠又實在"},
    {name:"12粒禮盒", price:400, note:"經濟實惠，全家共享"}
  ]
};
function loadData(){return JSON.parse(localStorage.getItem("yanyanData")||JSON.stringify(DEFAULT))}
const data=loadData(), cart={};
function shipFee(totalBoxes){ if(totalBoxes<=0)return 0; if(totalBoxes===1)return 160; if(totalBoxes<=3)return 225; if(totalBoxes<=8)return 290; return Math.ceil(totalBoxes/8)*290; }
function render(){
  document.querySelector(".notice").innerHTML=`<b>來電歡迎預訂</b><br>李先生：<a href="tel:${data.phone1}">${data.phone1}</a>　林小姐：<a href="tel:${data.phone2}">${data.phone2}</a>`;
  productList.innerHTML=data.products.map((p,i)=>`
    <div class="product">
      <h3>${p.name}</h3>
      <div class="price">${p.price}元</div>
      <div class="badge">${p.note||""}</div>
      <div class="qty">
        <button onclick="chg(${i},-1)">－</button><span id="q${i}">${cart[i]||0}</span><button onclick="chg(${i},1)">＋</button>
      </div>
    </div>`).join("");
  calc();
}
function chg(i,n){cart[i]=Math.max(0,(cart[i]||0)+n);render();}
function calc(){
  let subtotal=0, boxes=0, lines=[];
  data.products.forEach((p,i)=>{let q=cart[i]||0;if(q){boxes+=q;subtotal+=q*p.price;lines.push(`<div class="cartLine"><span>${p.name} × ${q}</span><b>${q*p.price}元</b></div>`)}});
  let shipping=shipFee(boxes);
  document.getElementById("cart").innerHTML=lines.join("")||"尚未選擇商品";
  subtotalEl=document.getElementById("subtotal"); subtotalEl.textContent=subtotal;
  document.getElementById("shipping").textContent=shipping;
  document.getElementById("grand").textContent=subtotal+shipping;
}
document.getElementById("orderBtn").onclick=()=>{
  const name=document.getElementById("name").value.trim(), phone=document.getElementById("phone").value.trim(), address=document.getElementById("address").value.trim();
  if(!name||!phone||!address){alert("請填寫姓名、手機、地址");return}
  let boxes=0, subtotal=0, items=[];
  data.products.forEach((p,i)=>{let q=cart[i]||0;if(q){boxes+=q;subtotal+=q*p.price;items.push(`${p.name} × ${q} = ${q*p.price}元`)}});
  if(!boxes){alert("請先選擇商品");return}
  const shipping=shipFee(boxes);
  const msg=`妍妍水蜜桃訂單%0A姓名：${name}%0A手機：${phone}%0A地址：${address}%0A商品：%0A${items.join("%0A")}%0A商品小計：${subtotal}元%0A運費：${shipping}元%0A總計：約${subtotal+shipping}元%0A付款：${document.getElementById("pay").value}%0A備註：${document.getElementById("note").value}`;
  window.open(`${data.lineLink}?text=${msg}`,"_blank");
};
render();