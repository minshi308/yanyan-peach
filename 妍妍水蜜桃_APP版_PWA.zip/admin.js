const DEFAULT = {
  lineLink: "https://line.me/R/ti/p/",
  phone1:"0978823328",
  phone2:"0981776979",
  products:[
    {name:"6粒禮盒", price:700, note:"數量有限需來電洽詢"},
    {name:"8粒禮盒", price:600, note:"大顆飽滿，送禮體面"},
    {name:"10粒禮盒", price:500, note:"份量剛好，實惠又實在"},
    {name:"12粒禮盒", price:400, note:"經濟實惠，全家共享"}
  ]
};
let data=JSON.parse(localStorage.getItem("yanyanData")||JSON.stringify(DEFAULT));
function renderAdmin(){
  lineLink.value=data.lineLink; phone1.value=data.phone1; phone2.value=data.phone2;
  adminProducts.innerHTML=data.products.map((p,i)=>`
    <div class="adminItem">
      <label>商品名稱<input value="${p.name}" onchange="data.products[${i}].name=this.value"></label>
      <label>價格<input type="number" value="${p.price}" onchange="data.products[${i}].price=Number(this.value)"></label>
      <label>備註<input value="${p.note}" onchange="data.products[${i}].note=this.value"></label>
      <button onclick="data.products.splice(${i},1);renderAdmin()">刪除</button>
    </div>`).join("");
}
function addProduct(){data.products.push({name:"新商品",price:0,note:""});renderAdmin()}
function saveAdmin(){
  data.lineLink=lineLink.value; data.phone1=phone1.value; data.phone2=phone2.value;
  localStorage.setItem("yanyanData",JSON.stringify(data));
  alert("已儲存！");
}
function resetDefault(){localStorage.setItem("yanyanData",JSON.stringify(DEFAULT));location.reload()}
renderAdmin();